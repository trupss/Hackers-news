export const environment = {
  production: false,
  apiUrl: "https://hacker-news.firebaseio.com/v0/"
};