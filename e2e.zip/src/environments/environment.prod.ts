export const environment = {
  production: true,
  apiUrl: "https://hacker-news.firebaseio.com/v0/"
};